The code that I am using for this project is c#
The data set is in the same directory as the .sh file
I have branched my code for part 1 and part 2 due to part two changing part 1 result.
To execute the program, all you have to do is execute the Assignment_1.sh by writing the following lines:

1. chmod +x Assignment_1.sh
2. ./Assignment_1.sh

Doing those two lines will comile both branches of the code and produce the output needed.